import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photo-management',
  templateUrl: './photos-management.component.html',
  styleUrls: ['./photos-management.component.css']
})
export class PhotoManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}